﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace MVCConApp
{
    internal class Class1
    {
        static void Main(string[] args)
        {
            practical1();
        }

        private static void practical1()
        {
            Console.WriteLine("Enter Your Name ");
            string UserName = Console.ReadLine();
            Console.WriteLine("Enter Your Age ");
            int age = int.Parse(Console.ReadLine());
            Console.WriteLine("Hello " + UserName + ",How are You?" + " Age is " + age.ToString());
        }
    }
}